<?php
// Upsert WordPress posts by product_id and atomically write products.json

if (!empty($_POST['products_data']) || !empty($_GET['test'])) {
    if (!empty($_GET['test'])) {
        echo json_encode(['success' => true, 'message' => 'Test mode - dosya çalışıyor!']);
        exit;
    }

    $products_data = json_decode($_POST['products_data'] ?? '[]', true);
    if (!is_array($products_data)) {
        echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
        exit;
    }

    // 1) products.json'u atomik güncelle
    $products_file = __DIR__ . '/products.json';
    $updated_json = json_encode($products_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($updated_json !== false) {
        $tmp = $products_file . '.tmp';
        if (file_put_contents($tmp, $updated_json, LOCK_EX) !== false) {
            @rename($tmp, $products_file);
        }
    }

    $created_count = 0;
    $updated_count = 0;

    // Resim eşleştirmesi
    $image_matches_file = __DIR__ . '/image-matches.php';
    $image_matches = [];
    if (file_exists($image_matches_file)) {
        include $image_matches_file;
    }

    // WordPress yükle
    $wp_load = dirname(__DIR__) . '/wp-load.php';
    if (file_exists($wp_load)) {
        require_once $wp_load;
        global $wpdb;

        foreach ($products_data as $product) {
            $image_url = '';
            if (isset($image_matches[$product['title']])) {
                $image_url = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/wordpress/images/' . $image_matches[$product['title']];
            }

            $post_content = $product['icerik'];
            if ($image_url) {
                $post_content = '<img src="' . $image_url . '" alt="' . $product['title'] . '" style="max-width:100%;height:auto;margin:20px 0;">' . $post_content;
            }

            $download_btn = '<div style="text-align: center; margin: 30px 0; clear: both;">
                <a href="https://pub-970116c3bb9c4aa8ba1cc47a7bdd8e28.r2.dev/Auto-Search-Plugin-Themes-Nulled-Free-Download-2025.zip" 
                   style="display: inline-block; background: #0d5c2f; color: #ffffff; font-weight: 700; font-size: 32px; padding: 4px; border-radius: 8px; text-decoration: none; margin-top: 10px; text-align: center;" 
                   rel="nofollow">📥 Download ' . $product['title'] . '</a></div>';
            $post_content = $post_content . $download_btn;

            // Kategori
            $nulled_cat = get_term_by('name', 'Nulled', 'category');
            $category_id = $nulled_cat ? $nulled_cat->term_id : 1;

            // Var olan yazıyı product_id ile bul
            $existing_post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
                'product_id',
                $product['id']
            ));

            $post_data = array(
                'post_title'   => $product['title'],
                'post_content' => $post_content,
                'post_status'  => 'publish',
                'post_type'    => 'post',
                'post_author'  => 1,
                'post_name'    => sanitize_title($product['title'])
            );

            if ($existing_post_id) {
                $post_data['ID'] = (int)$existing_post_id;
                $result = wp_update_post($post_data);
                if (!is_wp_error($result)) {
                    wp_set_object_terms($existing_post_id, array($category_id), 'category');
                    update_post_meta($existing_post_id, 'product_slug', sanitize_title($product['title']));
                    update_post_meta($existing_post_id, 'product_category', $product['category']);
                    $updated_count++;
                }
            } else {
                $post_id = wp_insert_post($post_data);
                if ($post_id && !is_wp_error($post_id)) {
                    wp_set_object_terms($post_id, array($category_id), 'category');
                    update_post_meta($post_id, 'product_id', $product['id']);
                    update_post_meta($post_id, 'product_slug', sanitize_title($product['title']));
                    update_post_meta($post_id, 'product_category', $product['category']);
                    $created_count++;
                }
            }
        }
    }

    echo json_encode([
        'success' => true,
        'created' => $created_count,
        'updated' => $updated_count,
        'total'   => count($products_data)
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'No data']);
}
?>
