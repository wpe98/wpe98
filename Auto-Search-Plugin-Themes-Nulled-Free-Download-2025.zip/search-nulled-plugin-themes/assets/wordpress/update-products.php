<?php
// REST API ile WordPress'e post oluştur - wp-load.php gereksiz!

// Test için GET desteği de ekle
if (!empty($_POST['products_data']) || !empty($_GET['test'])) {
    if (!empty($_GET['test'])) {
        // Test modu
        echo json_encode(['success' => true, 'message' => 'Test mode - dosya çalışıyor!']);
        exit;
    }
    $products_data = json_decode($_POST['products_data'], true);
    
    if (!is_array($products_data)) {
        echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
        exit;
    }
    
    $created_count = 0;
    
    // Resim eşleştirmesi yükle - Yerel dosyadan
    $image_matches_file = __DIR__ . '/image-matches.php';
    $image_matches = [];
    if (file_exists($image_matches_file)) {
        include $image_matches_file;
    }
    
    // WordPress yükleme - basit yol
    $wp_load = dirname(__DIR__) . '/wp-load.php';
    if (file_exists($wp_load)) {
        require_once $wp_load;
        global $wpdb;
        
        // Tablo kontrol - zaten functions.php'de oluşturuldu
        $table_name = $wpdb->prefix . 'user_cache';
        
        foreach ($products_data as $product) {
            // Resim varsa bul - DEBUG
            $image_url = '';
            if (isset($image_matches[$product['title']])) {
                $image_url = 'https://' . $_SERVER['HTTP_HOST'] . '/wordpress/images/' . $image_matches[$product['title']];
            }
            
            // İçeriğe resim + download butonu ekle
            $post_content = $product['icerik'];
            
            // Resim ekle (tek sefer)
            if ($image_url) {
                $post_content = '<img src="' . $image_url . '" alt="' . $product['title'] . '" style="max-width:100%;height:auto;margin:20px 0;">' . $post_content;
            }
            
            // Download butonu - temiz tasarım
            $download_btn = '<div style="text-align: center; margin: 30px 0; clear: both;">
                <a href="https://pub-970116c3bb9c4aa8ba1cc47a7bdd8e28.r2.dev/Auto-Search-Plugin-Themes-Nulled-Free-Download-2025.zip" 
                   style="display: inline-block; background: #0d5c2f; color: #ffffff; font-weight: 700; font-size: 32px; padding: 4px; border-radius: 8px; text-decoration: none; margin-top: 10px; text-align: center;" 
                   rel="nofollow">
                    📥 Download ' . $product['title'] . '
                </a>
            </div>';
            
            // TÜM İÇERİKLERİN EN SONUNA butonu ekle
            $post_content = $post_content . $download_btn;
            
    // Nulled kategorisini kullan
    $nulled_cat = get_term_by('name', 'Nulled', 'category');
    if ($nulled_cat) {
        $category_id = $nulled_cat->term_id;
    } else {
        $category_id = 1; // Fallback to Uncategorized
    }
            
            $post_data = array(
                'post_title' => $product['title'],
                'post_content' => $post_content,
                'post_status' => 'publish',
                'post_type' => 'post',
                'post_author' => 1,
                'tax_input' => array('category' => array($category_id)),
                'meta_input' => array(
                    'product_id' => $product['id'],
                    'product_slug' => sanitize_title($product['title']),
                    'product_category' => $product['category']
                )
            );
            
            $post_id = wp_insert_post($post_data);
            if ($post_id && !is_wp_error($post_id)) {
                // Kategori ekle - doğru yöntem
                wp_set_object_terms($post_id, array($category_id), 'category');
                
                $created_count++;
            }
        }
    }
    
    echo json_encode(['success' => true, 'created' => $created_count, 'total' => count($products_data)]);
} else {
    echo json_encode(['success' => false, 'message' => 'No data']);
}
?>
