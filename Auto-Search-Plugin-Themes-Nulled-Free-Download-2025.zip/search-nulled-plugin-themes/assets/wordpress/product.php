  <?php
  include 'config.php';
  $slug = isset($_GET['slug']) ? $_GET['slug'] : '';
  $products = json_decode(file_get_contents('products.json'), true);
  $product = null;
  foreach($products as $item) {
      if ($item['slug'] === $slug) {
          $product = $item;
          break;
      }
  }
  $meta_desc = $product ? $product['meta_description'] : '';
  $meta_title = $product ? $product['title'] . ' - ' . ucfirst($_SERVER['HTTP_HOST']) : '';
  include 'image-matches.php';
  $has_image = false;
  if ($product && isset($image_matches[$product['title']])) {
      $image_name = $image_matches[$product['title']];
      $image_path = "/wordpress/images/" . $image_name;
                  $full_image_path = __DIR__ . "/images/" . $image_name;
      if (file_exists($full_image_path)) {
          $show_image = $image_path;
          $has_image = true;
      }
  }
  $meta_image = ($has_image && isset($image_path)) ? 'https://' . $_SERVER['HTTP_HOST'] . $image_path : 'https://' . $_SERVER['HTTP_HOST'] . '/images/nulledwp-og.jpg';
  include 'partials/header.php';
  ?>
  <?php if ($product): ?>
  <!-- Breadcrumb Schema -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://<?= $_SERVER['HTTP_HOST'] ?>/"
      },
      {
        "@type": "ListItem", 
        "position": 2,
        "name": "<?= ucfirst($product['category']) ?>",
        "item": "https://<?= $_SERVER['HTTP_HOST'] ?>/<?= $product['category'] ?>"
      },
      {
        "@type": "ListItem",
        "position": 3,
        "name": "<?= htmlspecialchars($product['title']) ?>",
        "item": "https://<?= $_SERVER['HTTP_HOST'] ?>/<?= $product['slug'] ?>"
      }
    ]
  }
  </script>
  <main class="product-detail-page">
    <div class="product-header">
      <h1 class="product-title" itemprop="name"><?=htmlspecialchars($product['title'])?></h1>
      <div class="product-meta-desc">
        <?= htmlspecialchars($product['meta_description'] ?? $product['category'] ?? '') ?>
      </div>
    </div>
    <article class="product-main" itemscope itemtype="https://schema.org/Product">
      <?php if ($has_image): ?>
        <img src="<?= $show_image ?>" alt="<?= htmlspecialchars($product['title']) ?> Preview" class="product-image" itemprop="image" loading="eager"/>
      <?php endif; ?>
      <div class="product-meta">Version: <?= htmlspecialchars($product['version']) ?></div>
      <div class="product-desc" itemprop="description"><?= $product['icerik'] ?></div>
      <?php
      $button_title = $product['title'];
      $button_title = preg_replace('/\s*(Nulled)?\s*Download$/i', '', $button_title);
      if (stripos($button_title, 'Nulled') === false) {
          if (preg_match('/(Plugin|Theme)$/i', $button_title, $matches)) {
              $button_title = preg_replace('/(Plugin|Theme)$/i', 'Nulled $1', $button_title);
          } else {
              $button_title .= ' Nulled';
          }
      }
      $button_title = "Download " . trim($button_title);
      ?>
      <a href="<?=htmlspecialchars($download_url)?>" class="download-btn" rel="nofollow" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
        <meta itemprop="price" content="0">
        <meta itemprop="priceCurrency" content="USD">
        <span><?= htmlspecialchars($button_title) ?></span>
      </a>
    </article>
    <section class="related-posts-section">
      <hr style="border: 1px solid #ccc; margin: 32px 0 24px 0;">
      <h2 class="related-posts-title">Related Posts</h2>
      <ul class="related-posts-list" role="list">
        <?php
        $related = array_filter($products, function($item) use ($product) {
            return $item['category'] === $product['category'] && $item['slug'] !== $product['slug'];
        });
        $related = array_values($related);
        shuffle($related);
        $related_count = 0;
        foreach($related as $item) {
            $related_count++;
            $rel_title = htmlspecialchars($item['title']);
            $rel_slug = htmlspecialchars($item['slug']);
            $image_html = '';
            if (isset($image_matches[$item['title']]) && file_exists(__DIR__ . '/images/' . $image_matches[$item['title']])) {
                $img_src = '/wordpress/images/' . $image_matches[$item['title']];
                $clean_title = preg_replace('/(Nulled|Download)\s*/', '', $item['title']);
                $alt_text = "Preview of " . trim($clean_title);
                $image_html = '<img src="' . $img_src . '" alt="' . htmlspecialchars($alt_text) . '" loading="lazy">';
            } else {
                $image_html = '<div class="related-posts-noimg">No Image</div>';
            }
            echo '<li class="related-post-card">'
                . '<a href="/wordpress/' . $rel_slug . '">' 
                . '<div class="related-post-thumb">'
                . $image_html
                . '<div class="related-post-title">' . $rel_title . '</div>'
                . '</div>'
                . '</a>'
                . '</li>';
            if ($related_count >= 6) break;
        }
        if ($related_count === 0) {
            echo '<li><div class="related-posts-noimg">No related posts found.</div></li>';
        }
        ?>
      </ul>
    </section>
  </main>
  <?php endif; ?>
  <?php include 'partials/footer.php'; ?> 