<?php
if (!defined('ABSPATH')) exit;
?>
<div class="plugin-card">
    <div class="plugin-card-top">
        <div class="name column-name">
            <h3>Plugin Name</h3>
        </div>
        <div class="action-links">
            <ul class="plugin-action-buttons">
                <li><a class="install-now button" href="#">Download Now</a></li>
            </ul>
        </div>
    </div>
</div> 