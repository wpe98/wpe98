<?php if (!defined('ABSPATH')) exit; ?>

<div class="wpnull-modal" id="download-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Download Information</h3>
            <span class="close">&times;</span>
        </div>
        <div class="modal-body">
            <div class="download-info">
                <p>Version: <span class="version">5.2.3</span></p>
                <p>Size: <span class="size">2.3 MB</span></p>
                <p>Last Updated: <span class="date">2023-12-25</span></p>
            </div>
        </div>
    </div>
</div> 